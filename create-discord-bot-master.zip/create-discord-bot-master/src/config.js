module.exports = {
  token: process.env.TOKEN || require('../token').TOKEN
};
