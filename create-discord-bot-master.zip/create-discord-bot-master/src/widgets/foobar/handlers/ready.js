module.exports = async client => {
  console.log('foobar: ready');
};
